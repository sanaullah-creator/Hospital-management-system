<?php
session_start();
if (!isset($_SESSION['user'])) {
    header('Location: /signin.php');
    exit;
}

require_once __DIR__ . '/db.php';

$errors = [];
$success_popup = false;
$user_id = $_SESSION['user']['id'];
$doctor_id = intval($_GET['doctor_id'] ?? ($_POST['doctor_id'] ?? 0));

// Fetch doctors
$docStmt = $pdo->query("SELECT id, name, specialty FROM doctors ORDER BY name ASC");
$doctors = $docStmt->fetchAll();

// Handle appointment submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $doctor_id = intval($_POST['doctor_id']);
    $appointment_date = trim($_POST['appointment_date']);
    $appointment_time = trim($_POST['appointment_time']);
    $notes = trim($_POST['notes']);

    if (!$doctor_id || !$appointment_date) {
        $errors[] = "Please choose doctor and appointment date.";
    }

    if (empty($errors)) {
        $ins = $pdo->prepare("INSERT INTO bookings (user_id, doctor_id, appointment_date, appointment_time, notes, status)
                              VALUES (:user_id, :doctor_id, :date, :time, :notes, 'pending')");
        $ins->execute([
            'user_id' => $user_id,
            'doctor_id' => $doctor_id,
            'date' => $appointment_date,
            'time' => $appointment_time ?: null,
            'notes' => $notes
        ]);

        $success_popup = true;
    }
}

// Cancel appointment (only pending can be canceled)
if (isset($_GET['cancel_id'])) {
    $cancel_id = intval($_GET['cancel_id']);
    $cancel = $pdo->prepare("UPDATE bookings SET status='cancelled' WHERE id=:id AND user_id=:uid AND status='pending'");
    $cancel->execute(['id' => $cancel_id, 'uid' => $user_id]);
    echo "<script>
            alert('Your appointment has been cancelled.');
            window.location.href='booking.php';
          </script>";
}

// Fetch user booking history
$historyStmt = $pdo->prepare("
    SELECT b.*, d.name AS doctor_name, d.specialty 
    FROM bookings b
    JOIN doctors d ON b.doctor_id = d.id
    WHERE b.user_id = :uid
    ORDER BY b.id DESC
");
$historyStmt->execute(['uid' => $user_id]);
$history = $historyStmt->fetchAll();

require_once __DIR__ . '/includes/header.php';
?>
<!-- Background -->
<div class="min-h-screen py-16 px-4 bg-gradient-to-r from-indigo-500 via-purple-600 to-pink-500">

    <!-- Title -->
    <div class="max-w-4xl mx-auto mb-14 animate__animated animate__fadeInDown">
        <div class="bg-white/10 backdrop-blur-xl border border-white/30 shadow-2xl rounded-3xl p-8 text-white text-center">
            <h2 class="text-4xl font-extrabold tracking-wide mb-2 drop-shadow-lg">
                <i class="fa-solid fa-calendar-check mr-3"></i>Book Appointment
            </h2>
            <p class="opacity-90 text-lg">
                Schedule your visit with our specialists in just a few clicks.
            </p>
        </div>
    </div>

    <!-- Form Card -->
    <div class="max-w-2xl mx-auto bg-gradient-to-r from-cyan-600 to-teal-500 rounded-3xl shadow-2xl p-10 animate__animated animate__zoomIn text-white">

        <h2 class="text-3xl font-bold text-center mb-8 drop-shadow-lg">
            <i class="fa-solid fa-user-doctor mr-3"></i>Appointment Form
        </h2>

        <?php if ($errors): ?>
            <div class="mb-5 bg-red-100 text-red-700 p-4 rounded-xl shadow">
                <?php foreach ($errors as $e) echo "<div>".htmlspecialchars($e)."</div>"; ?>
            </div>
        <?php endif; ?>

        <form method="post" class="space-y-6">

            <div>
                <label class="block font-semibold mb-1"><i class="fa-solid fa-stethoscope mr-1"></i>Choose Doctor</label>
                <select name="doctor_id" required
                        class="w-full border border-white/30 bg-white/20 text-black px-4 py-3 rounded-xl shadow focus:ring-2 focus:ring-white">
                    <option value="" class="text-black">Select doctor</option>
                    <?php foreach ($doctors as $doc): ?>
                        <option value="<?= $doc['id'] ?>" <?= $doc['id'] == $doctor_id ? 'selected' : '' ?>>
                            <?= htmlspecialchars($doc['name'] . ' — ' . $doc['specialty']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="grid grid-cols-2 gap-4">
                <div>
                    <label class="block font-semibold mb-1"><i class="fa-solid fa-calendar-day mr-1"></i>Date</label>
                    <input type="date" name="appointment_date"
                           class="w-full border border-white/30 bg-white/20 text-white px-4 py-3 rounded-xl shadow">
                </div>

                <div>
                    <label class="block font-semibold mb-1"><i class="fa-solid fa-clock mr-1"></i>Time</label>
                    <input type="time" name="appointment_time"
                           class="w-full border border-white/30 bg-white/20 text-white px-4 py-3 rounded-xl shadow">
                </div>
            </div>

            <div>
                <label class="block font-semibold mb-1"><i class="fa-solid fa-note-sticky mr-1"></i>Notes</label>
                <textarea name="notes" rows="3"
                          class="w-full border border-white/30 bg-white/20 text-white px-4 py-3 rounded-xl shadow"></textarea>
            </div>

            <button type="submit"
                    class="w-full py-4 rounded-xl text-white font-bold text-lg 
                           bg-gradient-to-r from-white/30 to-white/10 shadow-lg hover:scale-105 transition-all">
                <i class="fa-solid fa-paper-plane mr-2"></i>Book Appointment
            </button>
        </form>
    </div>

    <!-- Success Popup -->
    <?php if ($success_popup): ?>
    <div id="successPopup"
         class="fixed inset-0 flex items-center justify-center bg-black/50 animate__animated animate__fadeIn">
        <div class="bg-white rounded-3xl shadow-2xl p-10 w-96 text-center animate__animated animate__zoomIn"
             style="box-shadow:0 20px 40px rgba(0,0,0,0.3);">
            <i class="fa-solid fa-circle-check text-teal-600 text-6xl mb-4"></i>
            <h3 class="text-2xl font-bold text-teal-700 mb-2">Appointment Booked!</h3>
            <p class="text-gray-600 text-md">
                Your appointment request has been submitted successfully.
            </p>
        </div>
    </div>

    
    <?php endif; ?>

    <!-- Appointment History -->
    <div class="bg-gradient-to-r from-indigo-500 via-purple-600 to-pink-500max-w-5xl mx-auto mt-20 mb-20 animate__animated animate__fadeInUp">
        <h2 class="text-4xl font-extrabold text-gray-800 text-center mb-10">
            <i class="fa-solid fa-clock-rotate-left mr-3"></i>Appointment History
        </h2>

        <?php if (!$history): ?>
            <div class="bg-gray-200 p-8 text-center rounded-3xl shadow-xl">
                <i class="fa-solid fa-folder-open text-5xl mb-3 text-gray-500"></i>
                <p class="text-gray-700 text-lg">No previous appointments found.</p>
            </div>
        <?php else: ?>
            <div class="space-y-6">
                <?php foreach ($history as $row): ?>
                    <div class="rounded-3xl p-8 shadow-xl border-l-8
                        <?php
                            if ($row['status'] == 'cancelled') echo 'bg-red-100 border-red-600';
                            elseif ($row['status'] == 'approved') echo 'bg-green-100 border-green-600';
                            elseif ($row['status'] == 'completed') echo 'bg-blue-100 border-blue-600';
                            else echo 'bg-yellow-100 border-yellow-500';
                        ?>
                        ">

                        <div class="flex justify-between items-start">
                            <div>
                                <h3 class="text-2xl font-bold mb-1"><?= htmlspecialchars($row['doctor_name']) ?></h3>
                                <p class="mb-3 font-medium"><?= htmlspecialchars($row['specialty']) ?></p>
                                <p><i class="fa-solid fa-calendar-day mr-1"></i><strong>Date:</strong> <?= htmlspecialchars($row['appointment_date']) ?></p>
                                <p><i class="fa-solid fa-clock mr-1"></i><strong>Time:</strong> <?= $row['appointment_time'] ?: 'Not set' ?></p>
                                <p class="mt-2"><strong>Notes:</strong> <?= htmlspecialchars($row['notes'] ?: 'None') ?></p>
                            </div>
                            <div class="text-right">
                                <?php if ($row['status'] == 'pending'): ?>
                                    <span class="bg-yellow-200 text-yellow-800 px-4 py-1 rounded-full text-sm font-bold shadow">Pending</span>
                                <?php elseif ($row['status'] == 'approved'): ?>
                                    <span class="bg-green-200 text-green-800 px-4 py-1 rounded-full text-sm font-bold shadow">Approved</span>
                                <?php elseif ($row['status'] == 'completed'): ?>
                                    <span class="bg-blue-200 text-blue-800 px-4 py-1 rounded-full text-sm font-bold shadow">Completed</span>
                                <?php else: ?>
                                    <span class="bg-red-200 text-red-800 px-4 py-1 rounded-full text-sm font-bold shadow">Cancelled</span>
                                <?php endif; ?>

                                <?php if ($row['status'] == 'pending'): ?>
                                    <a href="?cancel_id=<?= $row['id'] ?>" onclick="return confirm('Cancel this appointment?');"
                                       class="block mt-4 text-red-600 font-semibold hover:underline">
                                        <i class="fa-solid fa-xmark mr-1"></i>Cancel
                                    </a>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>

</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
