<?php 
require_once 'check_login.php';
require_once '../db.php';

$errors = [];
$success = '';

// ================= ADD DOCTOR =================
if (isset($_POST['add'])) {

    $name = trim($_POST['name'] ?? '');
    $specialty = trim($_POST['specialty'] ?? '');
    $qualification = trim($_POST['qualification'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $bio = trim($_POST['bio'] ?? '');

    $photo = '';

    if (!empty($_FILES['image']['name'])) {
        $uploadDir = __DIR__ . '/../uploads/doctors/';
        if (!is_dir($uploadDir)) {
            mkdir($uploadDir, 0777, true);
        }

        $fileName = time() . '_' . basename($_FILES['image']['name']);
        if (move_uploaded_file($_FILES['image']['tmp_name'], $uploadDir . $fileName)) {
            $photo = 'uploads/doctors/' . $fileName;
        }
    }

    if (!$name || !$specialty) {
        $errors[] = "Name and Specialty are required.";
    }

    if (!$errors) {
        $stmt = $pdo->prepare(
            "INSERT INTO doctors (name, specialty, qualification, phone, email, photo, bio)
             VALUES (?,?,?,?,?,?,?)"
        );
        $stmt->execute([
            $name, $specialty, $qualification, $phone, $email, $photo, $bio
        ]);
        $success = "Doctor added successfully.";
    }
}

// ================= DELETE DOCTOR =================
if (isset($_GET['delete'])) {
    $stmt = $pdo->prepare("DELETE FROM doctors WHERE id=?");
    $stmt->execute([intval($_GET['delete'])]);
    $success = "Doctor deleted successfully.";
}

// ================= EDIT DOCTOR =================
$editDoctor = null;

if (isset($_GET['edit'])) {
    $stmt = $pdo->prepare("SELECT * FROM doctors WHERE id=?");
    $stmt->execute([intval($_GET['edit'])]);
    $editDoctor = $stmt->fetch(PDO::FETCH_ASSOC);
}

if (isset($_POST['update'])) {
    $stmt = $pdo->prepare(
        "UPDATE doctors SET 
        name=?, specialty=?, qualification=?, phone=?, email=?, bio=? 
        WHERE id=?"
    );
    $stmt->execute([
        $_POST['name'],
        $_POST['specialty'],
        $_POST['qualification'],
        $_POST['phone'],
        $_POST['email'],
        $_POST['bio'],
        intval($_POST['id'])
    ]);
    $success = "Doctor updated successfully.";
}

// FETCH DOCTORS 
$doctors = $pdo->query("SELECT * FROM doctors ORDER BY name ASC")->fetchAll();
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Manage Doctors</title>
<script src="https://cdn.tailwindcss.com"></script>
</head>

<body class="bg-gradient-to-r from-purple-100 via-pink-50 to-yellow-100 flex min-h-screen">

<!-- Sidebar -->
<aside class="w-64 bg-gradient-to-b from-indigo-600 to-purple-700 text-white p-6">
<h2 class="text-3xl font-bold mb-8 text-center">Admin Panel</h2>
<ul class="space-y-4">
<li><a href="index.php" class="block px-4 py-2 rounded hover:bg-indigo-500">Dashboard</a></li>
<li><a href="doctors.php" class="block px-4 py-2 rounded bg-white text-indigo-700 font-semibold">Manage Doctors</a></li>
<li><a href="bookings.php" class="block py-2 px-4 rounded hover:bg-indigo-500 transition">Manage Bookings</a></li>
<li><a href="contacts.php" class="block py-2 px-4 rounded  text-white font-semibold">Contacts</a></li>
</ul>
<a href="logout.php" class="block mt-6 bg-red-500 py-2 rounded text-center font-bold">Logout</a>
</aside>

<!-- Main -->
<main class="flex-1 p-10">

<h1 class="text-4xl font-bold mb-6 text-purple-700">Manage Doctors</h1>

<?php if ($success): ?>
<div class="bg-green-100 text-green-700 p-3 mb-4 rounded">
<?= htmlspecialchars($success) ?>
</div>
<?php endif; ?>

<?php if ($errors): ?>
<div class="bg-red-100 text-red-700 p-3 mb-4 rounded">
<?php foreach ($errors as $e): ?>
<p><?= htmlspecialchars($e) ?></p>
<?php endforeach; ?>
</div>
<?php endif; ?>

<!-- ================= ADD DOCTOR FORM ================= -->
<div class="flex justify-center">
  <div class="bg-white p-8 rounded-2xl shadow-lg mb-10 w-full max-w-2xl">

    <h2 class="text-3xl font-bold text-center text-indigo-700 mb-6">
      Add Doctor
    </h2>

    <form method="post" enctype="multipart/form-data" class="space-y-5">

      <!-- Doctor Name -->
      <div>
        <label class="block text-sm font-medium text-gray-700 mb-1">
          Doctor Name
        </label>
        <input type="text" name="name" required
          class="w-full p-3 border rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500">
      </div>

      <!-- Specialty -->
      <div>
        <label class="block text-sm font-medium text-gray-700 mb-1">
          Specialty
        </label>
        <input type="text" name="specialty" required
          class="w-full p-3 border rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500">
      </div>

      <!-- Qualification -->
      <div>
        <label class="block text-sm font-medium text-gray-700 mb-1">
          Qualification
        </label>
        <input type="text" name="qualification"
          class="w-full p-3 border rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500">
      </div>

      <!-- Phone -->
      <div>
        <label class="block text-sm font-medium text-gray-700 mb-1">
          Phone
        </label>
        <input type="text" name="phone"
          class="w-full p-3 border rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500">
      </div>

      <!-- Email -->
      <div>
        <label class="block text-sm font-medium text-gray-700 mb-1">
          Email
        </label>
        <input type="email" name="email"
          class="w-full p-3 border rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500">
      </div>

      <!-- Photo -->
      <div>
        <label class="block text-sm font-medium text-gray-700 mb-1">
          Doctor Photo
        </label>
        <input type="file" name="image"
          class="w-full p-3 border rounded-xl bg-gray-50">
      </div>

      <!-- Bio -->
      <div>
        <label class="block text-sm font-medium text-gray-700 mb-1">
          Doctor Bio
        </label>
        <textarea name="bio" rows="4"
          class="w-full p-3 border rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500"></textarea>
      </div>

      <!-- Submit -->
      <button name="add"
        class="w-full bg-indigo-600 hover:bg-indigo-700 transition text-white py-3 rounded-xl font-semibold text-lg">
        Add Doctor
      </button>

    </form>
  </div>
</div>

<!-- ================= EDIT FORM ================= -->
<?php if ($editDoctor): ?>
<div class="bg-white p-6 rounded-xl shadow mb-8 max-w-2xl">
<h2 class="text-2xl font-semibold mb-4 text-indigo-700">Edit Doctor</h2>

<form method="post" class="grid grid-cols-1 md:grid-cols-2 gap-4">
<input type="hidden" name="id" value="<?= $editDoctor['id'] ?>">
<input name="name" value="<?= htmlspecialchars($editDoctor['name']) ?>" class="p-3 border rounded-xl">
<input name="specialty" value="<?= htmlspecialchars($editDoctor['specialty']) ?>" class="p-3 border rounded-xl">
<input name="qualification" value="<?= htmlspecialchars($editDoctor['qualification']) ?>" class="p-3 border rounded-xl">
<input name="phone" value="<?= htmlspecialchars($editDoctor['phone']) ?>" class="p-3 border rounded-xl">
<input name="email" value="<?= htmlspecialchars($editDoctor['email']) ?>" class="p-3 border rounded-xl">
<textarea name="bio" class="p-3 border rounded-xl md:col-span-2"><?= htmlspecialchars($editDoctor['bio']) ?></textarea>

<button name="update" class="md:col-span-2 bg-green-600 text-white p-3 rounded-xl font-bold">
Update Doctor
</button>
</form>
</div>
<?php endif; ?>

<!-- ================= DOCTORS TABLE ================= -->
<div class="bg-white rounded-xl shadow overflow-x-auto">
<table class="w-full">
<thead class="bg-indigo-600 text-white">
<tr>
<th class="p-3 text-left">Name</th>
<th class="p-3 text-left">Specialty</th>
<th class="p-3 text-left">Phone</th>
<th class="p-3 text-center">Actions</th>
</tr>
</thead>
<tbody>
<?php foreach ($doctors as $d): ?>
<tr class="border-b">
<td class="p-3"><?= htmlspecialchars($d['name']) ?></td>
<td class="p-3"><?= htmlspecialchars($d['specialty']) ?></td>
<td class="p-3"><?= htmlspecialchars($d['phone']) ?></td>
<td class="p-3 text-center space-x-2">
<a href="?edit=<?= $d['id'] ?>" class="bg-blue-500 text-white px-3 py-1 rounded">Edit</a>
<a href="?delete=<?= $d['id'] ?>" onclick="return confirm('Delete doctor?')" class="bg-red-500 text-white px-3 py-1 rounded">Delete</a>
</td>
</tr>
<?php endforeach; ?>
</tbody>
</table>
</div>

</main>
</body>
</html>
