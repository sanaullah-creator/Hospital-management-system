<?php
require_once 'check_login.php';
require_once '../db.php';

$success = '';

// Update booking status
if (isset($_GET['status']) && isset($_GET['id'])) {
    $id = intval($_GET['id']);
    $status = $_GET['status'];

    if (in_array($status, ['pending', 'confirmed', 'cancelled', 'completed'])) {
        $stmt = $pdo->prepare("UPDATE bookings SET status = :status WHERE id = :id");
        $stmt->execute(['status' => $status, 'id' => $id]);
        $success = "Booking status updated successfully!";
    }
}

// Delete booking
if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);
    $pdo->prepare("DELETE FROM bookings WHERE id = :id")->execute(['id' => $id]);
    $success = "Booking deleted successfully!";
}

// Fetch all bookings
$query = "
    SELECT b.id, b.appointment_date, b.appointment_time, b.status, b.notes,
           u.full_name AS user_name,
           d.name AS doctor_name
    FROM bookings b
    JOIN users u ON b.user_id = u.id
    JOIN doctors d ON b.doctor_id = d.id
    ORDER BY b.appointment_date DESC, b.appointment_time DESC
";

$bookings = $pdo->query($query)->fetchAll();
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Manage Bookings</title>
<script src="https://cdn.tailwindcss.com"></script>
</head>

<body class="bg-gradient-to-r from-purple-100 via-pink-50 to-yellow-100 flex">

<!-- LEFT SIDEBAR -->
<aside class="w-64 bg-gradient-to-b from-indigo-600 to-purple-700 text-white shadow-lg p-6 h-screen flex flex-col">
    <h2 class="text-3xl font-bold mb-8 text-center">Admin Panel</h2>
    <ul class="flex-1 space-y-4">
        <li><a href="index.php" class="block py-2 px-4 rounded hover:bg-indigo-500 transition">Dashboard</a></li>
        <li><a href="doctors.php" class="block py-2 px-4 rounded hover:bg-indigo-500 transition">Manage Doctors</a></li>
        <li><a href="bookings.php" class="block py-2 px-4 rounded bg-white text-indigo-700 font-semibold">Manage Bookings</a></li>
        <li><a href="contacts.php" class="block py-2 px-4 rounded hover:bg-indigo-500 transition">Messages</a></li>
    </ul>
    <a href="logout.php" class="mt-6 block py-2 px-4 rounded bg-red-500 hover:bg-red-700 text-center font-bold transition">Logout</a>
</aside>

<!-- MAIN CONTENT -->
<main class="flex-1 p-10">
    <h1 class="text-4xl font-extrabold mb-6 text-purple-700">Manage Bookings</h1>

    <?php if ($success): ?>
        <div class="bg-green-100 text-green-700 px-4 py-2 mb-4 rounded shadow">
            <?php echo htmlspecialchars($success); ?>
        </div>
    <?php endif; ?>

    <div class="overflow-x-auto">
    <table class="min-w-full bg-white rounded-xl shadow-lg">
        <thead class="bg-gray-200">
            <tr>
                <th class="px-6 py-3 text-left">#</th>
                <th class="px-6 py-3 text-left">User</th>
                <th class="px-6 py-3 text-left">Doctor</th>
                <th class="px-6 py-3 text-left">Date</th>
                <th class="px-6 py-3 text-left">Time</th>
                <th class="px-6 py-3 text-left">Status</th>
                <th class="px-6 py-3 text-left">Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php 
            $row_number = 1; // Start row count
            foreach ($bookings as $b): 
                $statusColor = match($b['status']) {
                    'pending' => 'bg-yellow-200 text-yellow-800',
                    'confirmed' => 'bg-green-200 text-green-800',
                    'cancelled' => 'bg-red-200 text-red-800',
                    'completed' => 'bg-blue-200 text-blue-800',
                    default => 'bg-gray-200 text-gray-800',
                };
            ?>
                <tr class="border-t hover:bg-gray-50 transition">
                    <td class="px-6 py-3"><?php echo $row_number++; // Auto increment ?></td>
                    <td class="px-6 py-3"><?php echo htmlspecialchars($b['user_name']); ?></td>
                    <td class="px-6 py-3"><?php echo htmlspecialchars($b['doctor_name']); ?></td>
                    <td class="px-6 py-3"><?php echo $b['appointment_date']; ?></td>
                    <td class="px-6 py-3"><?php echo $b['appointment_time']; ?></td>

                    <td class="px-6 py-3">
                        <span class="px-3 py-1 rounded-full font-semibold <?php echo $statusColor; ?>">
                            <?php echo ucfirst($b['status']); ?>
                        </span>
                    </td>

                    <td class="px-6 py-3 flex flex-wrap gap-2">
                        <?php if ($b['status'] !== 'confirmed'): ?>
                            <a href="?id=<?php echo $b['id']; ?>&status=confirmed" class="px-2 py-1 bg-green-500 text-white rounded hover:bg-green-600 transition">Confirm</a>
                        <?php endif; ?>
                        <?php if ($b['status'] !== 'cancelled'): ?>
                            <a href="?id=<?php echo $b['id']; ?>&status=cancelled" class="px-2 py-1 bg-red-500 text-white rounded hover:bg-red-600 transition">Cancel</a>
                        <?php endif; ?>
                        <?php if ($b['status'] !== 'completed'): ?>
                            <a href="?id=<?php echo $b['id']; ?>&status=completed" class="px-2 py-1 bg-blue-500 text-white rounded hover:bg-blue-600 transition">Complete</a>
                        <?php endif; ?>
                        <a href="?delete=<?php echo $b['id']; ?>" class="px-2 py-1 bg-gray-500 text-white rounded hover:bg-gray-600 transition">Delete</a>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
    </div>
</main>
</body>
</html>
