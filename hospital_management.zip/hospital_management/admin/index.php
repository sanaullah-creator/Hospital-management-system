<?php
require_once __DIR__.'/check_login.php';
require_once __DIR__.'/../db.php';

// Ensure admin session exists
$adminName = $_SESSION['admin']['name'] ?? 'Admin';
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Admin Dashboard</title>
<script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gradient-to-r from-purple-100 via-pink-50 to-yellow-100 font-sans">

<div class="min-h-screen flex">

  <!-- Sidebar -->
  <aside class="w-64 bg-gradient-to-b from-indigo-600 to-purple-700 text-white shadow-lg p-6 flex flex-col">
    <h2 class="text-3xl font-bold mb-8 text-center">Admin Panel</h2>
    <ul class="flex-1 space-y-4">
      <li><a href="index.php" class="block py-2 px-4 rounded bg-white text-indigo-700 font-semibold">Dashboard</a></li>
      <li><a href="doctors.php" class="block py-2 px-4 rounded hover:bg-indigo-500 transition font-semibold">Manage Doctors</a></li>
      <li><a href="bookings.php" class="block py-2 px-4 rounded hover:bg-indigo-500 transition font-semibold">Manage Bookings</a></li>
      <li><a href="contacts.php" class="block py-2 px-4 rounded hover:bg-indigo-500 transition font-semibold">Contacts</a></li>
    </ul>
    <a href="logout.php" class="mt-6 block py-2 px-4 rounded bg-red-500 hover:bg-red-700 text-center font-bold transition">Logout</a>
  </aside>

  <!-- Main Content -->
  <main class="flex-1 p-10">
    <h1 class="text-4xl font-extrabold mb-8 text-purple-700">Wellcome Sk to , <?php echo htmlspecialchars($adminName); ?>_panel</h1>

    <?php
    // Fetch counts safely
    $totalDoctors = $pdo->query("SELECT COUNT(*) FROM doctors")->fetchColumn() ?? 0;
   
    $totalBookings = $pdo->query("SELECT COUNT(*) FROM bookings")->fetchColumn() ?? 0;
    $totalContacts = $pdo->query("SELECT COUNT(*) FROM contacts")->fetchColumn() ?? 0;
    ?>

    <!-- Stats Cards -->
    <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
      
      <div class="bg-gradient-to-r from-green-400 to-green-200 text-white rounded-xl shadow-lg p-6 transform hover:scale-105 transition">
        <h3 class="uppercase font-bold text-lg">Doctors</h3>
        <div class="mt-2 text-4xl font-extrabold"><?php echo $totalDoctors; ?></div>
      </div>

      

      <div class="bg-gradient-to-r from-pink-400 to-pink-200 text-white rounded-xl shadow-lg p-6 transform hover:scale-105 transition">
        <h3 class="uppercase font-bold text-lg">Bookings</h3>
        <div class="mt-2 text-4xl font-extrabold"><?php echo $totalBookings; ?></div>
      </div>

      <div class="bg-gradient-to-r from-yellow-400 to-yellow-200 text-white rounded-xl shadow-lg p-6 transform hover:scale-105 transition">
        <h3 class="uppercase font-bold text-lg">Contacts</h3>
        <div class="mt-2 text-4xl font-extrabold"><?php echo $totalContacts; ?></div>
      </div>

    </div>
  </main>

</div>
</body>
</html>
