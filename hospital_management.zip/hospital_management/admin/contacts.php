<?php
require_once 'check_login.php';
require_once '../db.php';

$success = '';

// Delete contact message
if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);
    $pdo->prepare("DELETE FROM contacts WHERE id=:id")->execute(['id'=>$id]);
    $success = "Message deleted successfully.";
}

// Fetch all contacts
$contacts = $pdo->query("SELECT * FROM contacts ORDER BY created_at DESC")->fetchAll();
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>View Contacts</title>
<script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gradient-to-r from-purple-100 via-pink-50 to-yellow-100 flex min-h-screen">

<!-- Sidebar -->
<aside class="w-64 bg-gradient-to-b from-indigo-600 to-purple-700 text-white shadow-lg p-6 flex flex-col">
  <h2 class="text-3xl font-bold mb-8 text-center">Admin Panel</h2>
  <ul class="flex-1 space-y-4">
    <li><a href="index.php" class="block py-2 px-4 rounded hover:bg-indigo-500 transition">Dashboard</a></li>
    <li><a href="doctors.php" class="block py-2 px-4 rounded hover:bg-indigo-500 transition">Manage Doctors</a></li>
    
    <li><a href="bookings.php" class="block py-2 px-4 rounded hover:bg-indigo-500 transition">Manage Bookings</a></li>
    <li><a href="contacts.php" class="block py-2 px-4 rounded bg-white text-indigo-700 font-semibold">Contacts</a></li>
  </ul>
  <a href="logout.php" class="mt-6 block py-2 px-4 rounded bg-red-500 hover:bg-red-700 text-center font-bold transition">Logout</a>
</aside>

<!-- Main Content -->
<main class="flex-1 p-10">
  <h1 class="text-4xl font-extrabold mb-6 text-purple-700">User Messages</h1>

  <?php if ($success): ?>
    <div class="bg-green-100 text-green-700 px-4 py-2 mb-4 rounded shadow">
        <?php echo htmlspecialchars($success); ?>
    </div>
  <?php endif; ?>

  <div class="overflow-x-auto">
  <table class="min-w-full bg-white rounded-xl shadow-lg">
    <thead class="bg-gray-200">
      <tr>
        <th class="px-6 py-3 text-left">ID</th>
        <th class="px-6 py-3 text-left">Name</th>
        <th class="px-6 py-3 text-left">Email</th>
        <th class="px-6 py-3 text-left">Message</th>
        <th class="px-6 py-3 text-left">Date</th>
        <th class="px-6 py-3 text-left">Actions</th>
      </tr>
    </thead>
    <tbody>
      <?php foreach ($contacts as $c): ?>
        <tr class="border-t hover:bg-gray-50 transition">
          <td class="px-6 py-3"><?php echo $c['id']; ?></td>
          <td class="px-6 py-3"><?php echo htmlspecialchars($c['name']); ?></td>
          <td class="px-6 py-3"><?php echo htmlspecialchars($c['email']); ?></td>
          <td class="px-6 py-3"><?php echo htmlspecialchars($c['message']); ?></td>
          <td class="px-6 py-3"><?php echo htmlspecialchars($c['created_at']); ?></td>
          <td class="px-6 py-3">
            <a href="?delete=<?php echo $c['id']; ?>" class="px-3 py-1 bg-red-500 text-white rounded hover:bg-red-600 transition">Delete</a>
          </td>
        </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
  </div>
</main>
</body>
</html>
