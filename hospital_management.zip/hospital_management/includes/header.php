<?php 
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Hospital Management System</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <link rel="stylesheet" href="/assets/css/style.css">
</head>
<body class="bg-gray-100 text-gray-800">
  
<!-- Header -->
<header class="bg-gradient-to-r from-indigo-500 via-purple-600 to-pink-500 shadow-lg sticky top-0 z-50">
  <div class="container mx-auto px-6 py-4 flex items-center justify-between">

    <!-- Logo -->
    <a href="/index.php" class="flex items-center space-x-3 transform hover:scale-105 transition duration-300">
      <div class="bg-white text-indigo-600 rounded-full w-12 h-12 flex items-center justify-center font-bold shadow-lg">SK</div>
      <div>
        <h1 class="text-2xl font-bold text-white hover:text-yellow-300 transition">Hospital Management</h1>
        <p class="text-sm text-indigo-100">Care. Comfort. Confidence.</p>
      </div>
    </a>

    <!-- Hamburger Button (Mobile) -->
    <button id="menuBtn" class="md:hidden text-white text-3xl focus:outline-none">
      ☰
    </button>

    <!-- Navigation -->
    <nav id="menu"
         class="hidden md:flex flex-col  md:flex-row md:space-x-4 md:items-center absolute md:static top-full left-0 w-full md:w-auto
                bg-gradient-to-r from-indigo-500 via-purple-600 to-pink-500 md:bg-none
                flex-col md:flex-row px-6 md:px-0 py-4 md:py-0 shadow-lg md:shadow-none">

      <a href="/index.php" class="text-white font-medium hover:text-yellow-300 transition py-2 md:py-0">Home</a>
      <a href="/doctors.php" class="text-white font-medium hover:text-yellow-300 transition py-2 md:py-0">Doctors</a>
      
      <a href="/about.php" class="text-white font-medium hover:text-yellow-300 transition py-2 md:py-0">About</a>
      <a href="/contact.php" class="text-white font-medium hover:text-yellow-300 transition py-2 md:py-0">Contact</a>

      <?php if (isset($_SESSION['user'])): ?>
        <a href="/booking.php"
           class="text-white font-semibold px-3 py-2 rounded-lg bg-indigo-700 hover:bg-indigo-900 transition mt-2 md:mt-0">
           Get Appointment
        </a>

        <span class="px-3 py-1 mt-2 md:mt-0 rounded-full bg-yellow-100 text-yellow-700 font-semibold shadow-md animate-pulse">
          <?php echo htmlspecialchars($_SESSION['user']['full_name']); ?>
        </span>

        <a href="/logout.php"
           class="text-red-200 font-bold hover:text-red-400 transition mt-2 md:mt-0">
           Logout
        </a>
      <?php else: ?>
        <a href="/signin.php"
           class="px-4 py-2 flex items-center justify-center mt-2 w-24 h-10 md:mt-0 rounded-lg bg-gradient-to-r from-yellow-400 via-pink-500 to-purple-600
                  text-white font-bold shadow-lg hover:scale-105 transform transition">
           signin
        </a>
      <?php endif; ?>

    </nav>
  </div>
</header>

<!-- Toggle Script -->
<script>
  const btn = document.getElementById('menuBtn');
  const menu = document.getElementById('menu');

  btn.addEventListener('click', () => {
    menu.classList.toggle('hidden');
  });
</script>

<main class="container mx-auto px-6 py-8">
