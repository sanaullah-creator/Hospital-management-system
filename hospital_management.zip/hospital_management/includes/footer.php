</main>
<footer class="bg-black text-white mt-12 ">
  <div class="container mx-auto px-6 py-12 grid grid-cols-1 md:grid-cols-4 gap-10">

    <!-- Logo + About -->
    <div>
      <div class="flex items-center space-x-3">
        <img src="assets/images/logo.jpeg" class="h-12 w-12 rounded-full border-2 border-indigo-600" alt="Logo">
        <h2 class="text-xl font-bold text-white">Hospital Management</h2>
      </div>
      <p class="mt-3 text-gray-400 text-sm leading-relaxed">
        A place to recover from diseases with care and comfort.
      </p>
    </div>

    <!-- Quick Links -->
    <div>
      <h3 class="text-lg font-semibold text-white mb-4">Quick Links</h3>
      <ul class="space-y-2 text-sm">
        <li>
          <a href=" /index.php" class="flex items-center gap-2 hover:text-indigo-400 transition-colors duration-300">
            <i class="fa-solid fa-house"></i> Home
          </a>
        </li>
        <li>
          <a href=" /doctors.php" class="flex items-center gap-2 hover:text-indigo-400 transition-colors duration-300">
            <i class="fa-solid fa-user-doctor"></i> Doctors
          </a>
        </li>
        <li>
          <a href="/rooms.php" class="flex items-center gap-2 hover:text-indigo-400 transition-colors duration-300">
            <i class="fa-solid fa-bed"></i> Rooms
          </a>
        </li>
        <li>
          <a href="/about.php" class="flex items-center gap-2 hover:text-indigo-400 transition-colors duration-300">
            <i class="fa-solid fa-circle-info"></i> About Us
          </a>
        </li>
        <li>
          <a href="/contact.php" class="flex items-center gap-2 hover:text-indigo-400 transition-colors duration-300">
            <i class="fa-solid fa-envelope"></i> Contact
          </a>
        </li>
      </ul>
    </div>

    <!-- Developer & Designer -->
    <div>
      <h3 class="text-lg font-semibold text-white mb-4">Team</h3>
      <ul class="space-y-2 text-sm">
        <li class="flex items-center gap-2">
          <i class="fa-solid fa-code text-indigo-400"></i>
          <span class="text-gray-400">Developer:</span> <span class="hover:text-indigo-400 transition-colors duration-300">Sanaullah</span>
        </li>
        <li class="flex items-center gap-2">
          <i class="fa-solid fa-paint-brush text-pink-400"></i>
          <span class="text-gray-400">Designer:</span> <span class="hover:text-indigo-400 transition-colors duration-300">M.khuzaima</span>
        </li>
      </ul>
    </div>

    <!-- Social Links -->
    <div>
      <h3 class="text-lg font-semibold text-white mb-4">Follow Us</h3>
      <div class="flex gap-4 mt-2 text-2xl ">

        <a href="https://www.facebook.com" class="text-blue-600 hover:text-blue-400 transition-colors duration-300">
         <img src="assets/icons/facebook.svg" alt="Fast Service" class="w-8 h-8">
        </a>

        <a href="https://www.youtube.com" class="text-pink-500 hover:text-pink-400 transition-colors duration-300">
          <img src="assets/icons/youtube.svg" alt="Fast Service" class="w-8 h-8">
        </a>

        <a href="https://www.google.com" class="text-red-500 hover:text-red-400 transition-colors duration-300">
         <img src="assets/icons/google.svg" alt="Fast Service" class="w-8 h-8">
        </a>

      </div>
    </div>

  </div>

  <!-- Bottom Bar -->
  <div class="border-t border-gray-700 mt-10 py-4 text-center text-xs text-gray-500">
    © <?php echo date('Y'); ?> SK Hospital — All Rights Reserved developed by sanaullah
  </div>
</footer>

<script src="/assets/js/script.js"></script>
</body>
</html>
