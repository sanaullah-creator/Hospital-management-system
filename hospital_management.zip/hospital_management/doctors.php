<?php
require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/db.php';

// fetch doctors
$stmt = $pdo->query("SELECT * FROM doctors ORDER BY name ASC");
$doctors = $stmt->fetchAll();
?>

<section class="bg-white p-6 rounded-xl shadow-md mt-6">
  <h2 class="text-3xl font-bold text-gray-800 mb-6 text-center">Our Doctors</h2>

  <?php if (empty($doctors)): ?>
    <p class="text-gray-600 text-center">No doctor found.</p>
  <?php else: ?>
    <div class="grid md:grid-cols-3 gap-6">
      <?php foreach ($doctors as $d): ?>
        <div class="bg-gradient-to-r from-indigo-50 to-blue-50 p-6 rounded-2xl shadow-md hover:shadow-xl transition-transform duration-300 transform hover:-translate-y-2">
          <div class="flex items-center gap-4 mb-4">
            <img src="<?php echo htmlspecialchars($d['photo'] ?: '/assets/images/doctor-placeholder.png'); ?>" alt="Dr" class="w-20 h-20 object-cover rounded-full border-2 border-indigo-400">
            <div>
              <h3 class="font-semibold text-lg text-gray-800"><?php echo htmlspecialchars($d['name']); ?></h3>
              <p class="text-sm text-indigo-600 font-medium"><?php echo htmlspecialchars($d['specialty']); ?></p>
              <p class="text-xs text-gray-500"><?php echo htmlspecialchars($d['qualification']); ?></p>
            </div>
          </div>

          <p class="text-gray-700 text-sm mb-4 line-clamp-3"><?php echo htmlspecialchars($d['bio']); ?></p>

          <div class="flex items-center justify-between">
            <a href="/doctor_detail.php?id=<?php echo $d['id']; ?>" class="text-sm text-indigo-600 font-semibold hover:underline hover:text-indigo-800 transition-colors duration-300">View Details</a>

            <?php if (isset($_SESSION['user'])): ?>
              <a href="/booking.php?doctor_id=<?php echo $d['id']; ?>" class="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-full text-sm font-medium transition-colors duration-300 shadow-md hover:shadow-lg">Book</a>
            <?php else: ?>
              <a href="/signin.php" class="px-4 py-2 border border-indigo-600 text-indigo-600 hover:bg-indigo-100 rounded-full text-sm font-medium transition-colors duration-300">Sign in to Book</a>
            <?php endif; ?>
          </div>
        </div>
      <?php endforeach; ?>
    </div>
  <?php endif; ?>
</section>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
