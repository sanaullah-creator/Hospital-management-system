<?php
require_once 'includes/header.php';
?>

<!-- About Us Hero Section -->
<section class="bg-gray-50 py-20">
    <div class="container mx-auto px-6 lg:px-24 flex flex-col lg:flex-row items-center gap-12">
        
        <!-- Left: Info Card -->
        <div class="lg:w-1/2 bg-white rounded-xl shadow-xl p-10">
            <h2 class="text-4xl font-bold text-gray-800 mb-6">About SK Hospital</h2>
            <p class="text-gray-600 mb-6 leading-relaxed">
                <span class="font-semibold text-indigo-600">SK Hospital</span> is committed to providing world-class medical care with compassion and professionalism. Our hospital combines advanced technology with experienced doctors to ensure every patient receives the best treatment.
            </p>
            <p class="text-gray-600 mb-4 leading-relaxed">
                Our mission is to deliver healthcare services with integrity, excellence, and empathy. We prioritize patient safety, comfort, and satisfaction above all.
            </p>
            <ul class="list-disc list-inside text-gray-600 space-y-2 mb-6">
                <li>24/7 Emergency Services</li>
                <li>Highly Qualified Doctors & Specialists</li>
                <li>Modern Diagnostic & Treatment Facilities</li>
                <li>Patient-Centered Care</li>
            </ul>
            <a href="contact.php" class="inline-block mt-4 px-6 py-3 bg-indigo-600 text-white rounded-lg shadow-lg hover:bg-indigo-500 transition duration-300">Contact Us</a>
        </div>

        <!-- Right: Hospital Image -->
        <div class="lg:w-1/2">
            <img src="assets/images/building.jpg" alt="SK Hospital Image" class="rounded-xl shadow-2xl object-cover w-full h-full">
        </div>
    </div>
</section>

<!-- Our Team Section -->
<section class="py-20 bg-white">
    <div class="container mx-auto px-6 lg:px-24 text-center">
        <h2 class="text-4xl font-bold text-gray-800 mb-12">Our Team</h2>
        <div class="grid grid-cols-1 md:grid-cols-2 gap-12 justify-items-center">

            <!-- Team Card 1 -->
            <div class="bg-gray-50 rounded-2xl shadow-lg p-8 transform hover:-translate-y-2 hover:shadow-2xl transition duration-300 w-full max-w-sm">
                <img src="assets/images/khuzaima.jpeg" alt="Doctor" class="w-32 h-32 mx-auto rounded-full border-4 border-indigo-500 mb-6 object-cover">
                <h3 class="text-2xl font-semibold text-gray-800 mb-2">Designer</h3>
                <p class="text-indigo-600 font-medium mb-4">tailwind css,php</p>
                
            </div>

            <!-- Team Card 2 -->
            <div class="bg-gray-50 rounded-2xl shadow-lg p-8 transform hover:-translate-y-2 hover:shadow-2xl transition duration-300 w-full max-w-sm">
                <img src="assets/images/doctor3.jpg" alt="Developer" class="w-32 h-32 mx-auto rounded-full border-4 border-indigo-500 mb-6 object-cover">
                <h3 class="text-2xl font-semibold text-gray-800 mb-2">Developer</h3>
                <p class="text-indigo-600 font-medium mb-4">tailwind css ,php</p>
                
            </div>

        </div>
    </div>
</section>

<?php
require_once 'includes/footer.php';
?>
