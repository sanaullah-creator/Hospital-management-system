<?php
session_start();
require_once __DIR__ . '/db.php';

$errors = [];
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $full_name = trim($_POST['full_name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $password = $_POST['password'] ?? '';
    $password_confirm = $_POST['password_confirm'] ?? '';

    // Required fields validation
    if (!$full_name || !$email || !$password || !$password_confirm) {
        $errors[] = "Please fill all required fields.";
    }

    // Email format check
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = "Invalid email format.";
    }

    // Password match check
    if ($password !== $password_confirm) {
        $errors[] = "Passwords do not match.";
    }

    if (empty($errors)) {
        // Check if email already exists
        $stmt = $pdo->prepare("SELECT id FROM users WHERE email = :email LIMIT 1");
        $stmt->execute(['email' => $email]);

        if ($stmt->fetch()) {
            $errors[] = "Email already registered. Try signing in.";
        } else {
            // Hash password
            $hashed = password_hash($password, PASSWORD_DEFAULT);

            // Insert new user
            $insert = $pdo->prepare("
                INSERT INTO users (full_name, email, phone, password)
                VALUES (:full_name, :email, :phone, :password)
            ");

            $insert->execute([
                'full_name' => $full_name,
                'email' => $email,
                'phone' => $phone,
                'password' => $hashed
            ]);

            // Success message
            $success = "Registration successful! Redirecting...";

            // Redirect to signin after 1.5 seconds
            header("refresh:1.5; url=signin.php");
        }
    }
}

require_once __DIR__ . '/includes/header.php';
?>

<div class="max-w-md mx-auto bg-white p-6 rounded shadow mt-10">
    <h2 class="text-2xl font-semibold text-center mb-4">Create an Account</h2>

    <!-- Error Messages -->
    <?php if (!empty($errors)): ?>
        <div class="mb-4 text-red-600">
            <?php foreach ($errors as $e): ?>
                <div><?= htmlspecialchars($e) ?></div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>

    <!-- Success Message -->
    <?php if ($success): ?>
        <div class="mb-4 text-green-600 font-medium">
            <?= htmlspecialchars($success) ?>
        </div>
    <?php endif; ?>

    <form method="post" class="space-y-4">

        <div>
            <label class="block text-sm font-medium">Full Name</label>
            <input type="text" name="full_name" required
                value="<?= htmlspecialchars($_POST['full_name'] ?? '') ?>"
                class="w-full border px-3 py-2 rounded focus:ring focus:ring-indigo-200" />
        </div>

        <div>
            <label class="block text-sm font-medium">Email</label>
            <input type="email" name="email" required
                value="<?= htmlspecialchars($_POST['email'] ?? '') ?>"
                class="w-full border px-3 py-2 rounded focus:ring focus:ring-indigo-200" />
        </div>

        <div>
            <label class="block text-sm font-medium">Phone (optional)</label>
            <input type="text" name="phone"
                value="<?= htmlspecialchars($_POST['phone'] ?? '') ?>"
                class="w-full border px-3 py-2 rounded focus:ring focus:ring-indigo-200" />
        </div>

        <div>
            <label class="block text-sm font-medium">Password</label>
            <input type="password" name="password" required
                class="w-full border px-3 py-2 rounded focus:ring focus:ring-indigo-200" />
        </div>

        <div>
            <label class="block text-sm font-medium">Confirm Password</label>
            <input type="password" name="password_confirm" required
                class="w-full border px-3 py-2 rounded focus:ring focus:ring-indigo-200" />
        </div>

        <button type="submit"
            class="w-full bg-indigo-600 text-white py-2 rounded hover:bg-indigo-700">
            Register
        </button>
    </form>

    <p class="mt-4 text-sm text-gray-700 text-center">
        Already have an account?
        <a href="signin.php" class="text-indigo-600 font-medium">Sign in</a>
    </p>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
