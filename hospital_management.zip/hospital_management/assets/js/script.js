// script.js - placeholder for interactions
document.addEventListener('DOMContentLoaded', function() {
  // Example: focus first input on signin page
  const emailInput = document.querySelector('input[name="email"]');
  if (emailInput) emailInput.focus();
});
