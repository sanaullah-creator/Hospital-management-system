<?php
session_start();
require_once __DIR__ . '/db.php';

$errors = [];

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $email_or_user = trim($_POST['email'] ?? '');
    $password = trim($_POST['password'] ?? '');

    if (!$email_or_user || !$password) {
        $errors[] = "Email/Username and password are required.";
    } else {
        //Check admin login
        $stmt_admin = $pdo->prepare("SELECT * FROM admins WHERE username = :u LIMIT 1");
        $stmt_admin->execute(['u' => $email_or_user]);
        $admin = $stmt_admin->fetch();

        if ($admin && hash('sha256', $password) === $admin['password']) {
            $_SESSION['admin'] = [
                'id' => $admin['id'],
                'username' => $admin['username'],
                'name' => $admin['name'] ?? 'Admin'
            ];
            header("Location: /admin/index.php");
            exit;
        }

        //Check user login
        $stmt_user = $pdo->prepare("SELECT * FROM users WHERE email = :e LIMIT 1");
        $stmt_user->execute(['e' => $email_or_user]);
        $user = $stmt_user->fetch();

        if ($user && password_verify($password, $user['password'])) {
            $_SESSION['user'] = [
                'id' => $user['id'],
                'full_name' => $user['full_name'],
                'email' => $user['email']
            ];
            header("Location: /index.php");
            exit;
        }

        //Login failed
        $errors[] = "Invalid username/email or password!";
    }
}
?>

<?php require_once __DIR__ . '/includes/header.php'; ?>

<div class="max-w-md mx-auto bg-white p-6 rounded shadow mt-10">
  <h2 class="text-2xl font-bold mb-6 text-center text-indigo-700">Sign In</h2>

  <?php if ($errors): ?>
      <div class="mb-4 text-red-600">
          <?php foreach ($errors as $e) echo "<div>".htmlspecialchars($e)."</div>"; ?>
      </div>
  <?php endif; ?>

  <form method="post" class="space-y-4">
    <div>
      <label class="block text-sm font-medium">Username / Email</label>
      <input name="email" type="text" required class="w-full border px-3 py-2 rounded focus:outline-none focus:ring-2 focus:ring-indigo-500" />
    </div>
    <div>
      <label class="block text-sm font-medium">Password</label>
      <input name="password" type="password" required class="w-full border px-3 py-2 rounded focus:outline-none focus:ring-2 focus:ring-indigo-500" />
    </div>
    <button type="submit" class="w-full bg-indigo-600 text-white py-2 rounded hover:bg-indigo-700 transition">Sign In</button>
  </form>

  <p class="mt-4 text-sm text-gray-600 text-center">
    Don't have an account? <a href="signup.php" class="text-indigo-600 font-bold">Sign up now</a>
  </p>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
