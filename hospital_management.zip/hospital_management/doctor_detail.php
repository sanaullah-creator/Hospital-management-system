<?php
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/includes/header.php';

$id = intval($_GET['id'] ?? 0);
$stmt = $pdo->prepare("SELECT * FROM doctors WHERE id = :id LIMIT 1");
$stmt->execute(['id' => $id]);
$d = $stmt->fetch();

if (!$d) {
    echo "<div class='bg-white p-6 rounded shadow'>Doctor not found.</div>";
    require_once __DIR__ . '/includes/footer.php';
    exit;
}
?>

<div class="bg-white p-6 rounded shadow">
  <div class="flex gap-6 items-start">
    <img src="<?php echo htmlspecialchars($d['photo'] ?: '/assets/images/doctor-placeholder.png'); ?>" class="w-48 h-48 object-cover rounded" alt="Doctor">
    <div>
      <h2 class="text-2xl font-semibold"><?php echo htmlspecialchars($d['name']); ?></h2>
      <p class="text-sm text-gray-600"><?php echo htmlspecialchars($d['specialty']); ?> — <?php echo htmlspecialchars($d['qualification']); ?></p>
      <p class="mt-4 text-gray-700"><?php echo nl2br(htmlspecialchars($d['bio'])); ?></p>

      <div class="mt-6">
        <?php if (isset($_SESSION['user'])): ?>
          <a href="/booking.php?doctor_id=<?php echo $d['id']; ?>" class="px-4 py-2 bg-indigo-600 text-white rounded">Book Appointment</a>
        <?php else: ?>
          <a href="/signin.php" class="px-4 py-2 border rounded">Sign in to book</a>
        <?php endif; ?>
      </div>
    </div>
  </div>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
