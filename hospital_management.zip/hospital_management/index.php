<?php
require_once __DIR__ . '/includes/header.php';
?>
<!-- Hero Section -->
<section class="bg-white p-6 rounded-lg shadow-lg mt-6">
  <div class="flex flex-col md:flex-row items-center gap-6">
    <div class="flex-1">
      <h2 class="text-4xl font-extrabold text-gray-800 mb-3 bg-clip-text text-transparent bg-black">
        Welcome to SK Hospital
      </h2>
      <p class="mt-3 text-gray-600 text-lg">We provide excellent healthcare services with experienced doctors and comfortable rooms. Use this system to view doctors and book appointments (login required).</p>
      <div class="mt-6 flex flex-wrap gap-3">
        <a href="/doctors.php" class="px-6 py-3 bg-green-700 text-white rounded-lg font-bold shadow-lg  transform transition duration-300">View Doctors</a>
        
      </div>
    </div>
    <div class="w-full md:w-1/3">
      <img src="assets/images/building.jpg" alt="Hospital" class="rounded-lg shadow-lg object-cover w-full h-56 hover:scale-105 transition transform duration-500">
    </div>
  </div>
</section>

<!-- Services Section -->
<section class="mt-10 grid md:grid-cols-3 gap-6">
  <div class="bg-white p-6 rounded-xl shadow-md hover:shadow-xl transition transform hover:-translate-y-2">
    <h3 class="font-semibold text-xl mb-2">Emergency Care</h3>
    <p class="text-gray-600 text-sm">24/7 emergency services with trained staff.</p>
  </div>
  <div class="bg-white p-6 rounded-xl shadow-md hover:shadow-xl transition transform hover:-translate-y-2">
    <h3 class="font-semibold text-xl mb-2">Qualified Doctors</h3>
    <p class="text-gray-600 text-sm">Specialists across multiple disciplines.</p>
  </div>
  <div class="bg-white p-6 rounded-xl shadow-md hover:shadow-xl transition transform hover:-translate-y-2">
    <h3 class="font-semibold text-xl mb-2">Comfortable Rooms</h3>
    <p class="text-gray-600 text-sm">Private and general wards available.</p>
  </div>
</section>

<!-- Feature Cards -->
<section class="py-16 pt-10 bg-gray-50">
  <div class="max-w-7xl mx-auto grid gap-10 md:grid-cols-3">

    <div class="bg-white p-8 rounded-xl shadow-md hover:shadow-2xl transition transform hover:-translate-y-2 text-center">
      <img src="assets/icons/advance.svg" class="mx-auto mb-6 w-20" alt="Advanced Technology">
      <h3 class="text-xl font-bold text-gray-800 mb-4">ADVANCED TECHNOLOGY</h3>
      <p class="text-gray-600 leading-relaxed">SK Hospital uses modern medical equipment to ensure accurate diagnosis and effective treatment. Our advanced technology helps doctors provide faster, safer, and more reliable care.</p>
    </div>

    <div class="bg-white p-8 rounded-xl shadow-md hover:shadow-2xl transition transform hover:-translate-y-2 text-center">
      <img src="assets/icons/healthcare.svg" class="mx-auto mb-6 w-20" alt="Healthcare Solutions">
      <h3 class="text-xl font-bold text-gray-800 mb-4">HEALTHCARE SOLUTIONS</h3>
      <p class="text-gray-600 leading-relaxed">Complete medical solutions with expert doctors and advanced care systems for precise and compassionate treatments.</p>
    </div>

    <div class="bg-white p-8 rounded-xl shadow-md hover:shadow-2xl transition transform hover:-translate-y-2 text-center">
      <img src="assets/icons/ambulance.svg" class="mx-auto mb-6 w-20" alt="Availability">
      <h3 class="text-xl font-bold text-gray-800 mb-4">24/7 AVAILABILITY</h3>
      <p class="text-gray-600 leading-relaxed">Immediate medical assistance round the clock. Our emergency team ensures quick and reliable patient care anytime.</p>
    </div>

  </div>
</section>

<!-- Why Us Section -->
<section class="py-20 bg-gray-50">
  <div class="max-w-7xl mx-auto px-6">

    <div class="text-center mb-14">
      <h2 class="text-4xl font-bold text-gray-800 bg-clip-text text-transparent bg-gradient-to-r from-indigo-600 via-purple-600 to-pink-500">
        Why Choose SK Hospital?
      </h2>
      <p class="mt-4 text-gray-600 max-w-2xl mx-auto">
        Trusted, advanced, and patient-focused healthcare services round the clock.
      </p>
    </div>

    <div class="grid gap-10 md:grid-cols-3">

      <!-- Card 1 -->
      <div class="bg-white p-8 rounded-2xl shadow-md hover:shadow-xl transition transform hover:-translate-y-2 text-center">
        <div class="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-6">
          <img src="assets/icons/doctor.svg" alt="Expert Doctors" class="w-8 h-8">
        </div>
        <h3 class="text-xl font-semibold text-gray-800 mb-3">Expert Doctors</h3>
        <p class="text-gray-600">
          Skilled and specialized doctors delivering accurate and personalized medical care.
        </p>
      </div>

      <!-- Card 2 -->
      <div class="bg-white p-8 rounded-2xl shadow-md hover:shadow-xl transition transform hover:-translate-y-2 text-center">
        <div class="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-6">
          <img src="assets/icons/technology.svg" alt="Modern Technology" class="w-8 h-8">
        </div>
        <h3 class="text-xl font-semibold text-gray-800 mb-3">Modern Technology</h3>
        <p class="text-gray-600">
          Equipped with advanced medical machines for safe, quick, and accurate treatment.
        </p>
      </div>

      <!-- Card 3 -->
      <div class="bg-white p-8 rounded-2xl shadow-md hover:shadow-xl transition transform hover:-translate-y-2 text-center">
        <div class="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-6">
          <img src="assets/icons/ambulance.svg" alt="24/7 Availability" class="w-8 h-8">
        </div>
        <h3 class="text-xl font-semibold text-gray-800 mb-3">24/7 Availability</h3>
        <p class="text-gray-600">
          Emergency care, ambulance service, and support staff available every hour of the day.
        </p>
      </div>

      <!-- Card 4 -->
      <div class="bg-white p-8 rounded-2xl shadow-md hover:shadow-xl transition transform hover:-translate-y-2 text-center">
        <div class="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-6">
          <img src="assets/icons/dollars.svg" alt="Affordable Pricing" class="w-8 h-8">
        </div>
        <h3 class="text-xl font-semibold text-gray-800 mb-3">Affordable Pricing</h3>
        <p class="text-gray-600">
          Quality healthcare with transparent costs and no hidden charges for patients.
        </p>
      </div>

      <!-- Card 5 -->
      <div class="bg-white p-8 rounded-2xl shadow-md hover:shadow-xl transition transform hover:-translate-y-2 text-center">
        <div class="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-6">
          <img src="assets/icons/clean.svg" alt="Clean Environment" class="w-8 h-8">
        </div>
        <h3 class="text-xl font-semibold text-gray-800 mb-3">Clean Environment</h3>
        <p class="text-gray-600">
          A hygienic, safe, and comfortable environment that supports faster recovery.
        </p>
      </div>

      <!-- Card 6 -->
      <div class="bg-white p-8 rounded-2xl shadow-md hover:shadow-xl transition transform hover:-translate-y-2 text-center">
        <div class="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-6">
          <img src="assets/icons/availability.svg" alt="Fast Service" class="w-8 h-8">
        </div>
        <h3 class="text-xl font-semibold text-gray-800 mb-3">Fast Service</h3>
        <p class="text-gray-600">
          Minimum waiting time with efficient staff and streamlined patient processing.
        </p>
      </div>

    </div>
  </div>
</section>


<!-- Tips Section -->
<section class="py-16 bg-blue-50">
  <div class="max-w-4xl mx-auto px-6">
    <h2 class="text-4xl font-bold text-center text-gray-800 mb-10">
      Today’s Tip from <span class="text-blue-600">Dr. Sanaullah</span>
    </h2>

    <div class="bg-white shadow-lg rounded-2xl p-8 md:p-10 border-l-4 border-blue-600">
      <div class="w-14 h-14 bg-blue-100 text-blue-600 rounded-full flex items-center justify-center text-3xl mb-6 animate-pulse">
         <div>
          <img src="assets/icons/hint.svg" alt="Fast Service" class="w-8 h-8">
        </div>
      </div>
      <ul class="space-y-4 text-gray-700 leading-relaxed">
        <li class="flex gap-3"><span class="text-blue-600 text-xl">•</span>Drink 6-8 glasses of water daily to maintain proper hydration.</li>
        <li class="flex gap-3"><span class="text-blue-600 text-xl">•</span>Take a short walk every day to improve heart and lung health.</li>
        <li class="flex gap-3"><span class="text-blue-600 text-xl">•</span>Get a minimum of 7-8 hours of sleep for better energy and immune strength.</li>
      </ul>
      <div class="mt-6 text-right text-gray-700 font-medium">Dr. Sanaullah</div>
    </div>
  </div>
</section>

<?php
require_once __DIR__ . '/includes/footer.php';
?>
