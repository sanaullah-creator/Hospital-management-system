<?php
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/includes/header.php';

$errors = [];
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $subject = trim($_POST['subject'] ?? '');
    $message = trim($_POST['message'] ?? '');

    if (!$name || !$email || !$message) {
        $errors[] = "Name, email, and message are required.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = "Invalid email address.";
    } else {
        $ins = $pdo->prepare("INSERT INTO contacts (name, email, subject, message) VALUES (:name, :email, :subject, :message)");
        $ins->execute([
            'name' => $name,
            'email' => $email,
            'subject' => $subject,
            'message' => $message
        ]);
        $success = "Message sent successfully! We'll respond soon.";
        $_POST = []; // Clear form
    }
}
?>

<section class="max-w-xl mx-auto my-12 px-4">
  <div class="bg-white p-8 rounded-2xl shadow-md">
    <h2 class="text-2xl font-bold mb-6 text-gray-800">Contact Us</h2>

    <?php if ($errors): ?>
      <div class="mb-4 p-3 bg-red-50 border-l-4 border-red-500 text-red-700 rounded">
        <?php foreach ($errors as $e) echo "<div>".htmlspecialchars($e)."</div>"; ?>
      </div>
    <?php endif; ?>

    <?php if ($success): ?>
      <div class="mb-4 p-3 bg-green-50 border-l-4 border-green-500 text-green-700 rounded">
        <?php echo htmlspecialchars($success); ?>
      </div>
    <?php endif; ?>

    <form method="post" class="space-y-5">
      <div>
        <label class="block text-sm font-medium mb-1">Name</label>
        <input name="name" value="<?php echo htmlspecialchars($_POST['name'] ?? ''); ?>" class="w-full border border-gray-300 px-3 py-2 rounded focus:ring-2 focus:ring-indigo-400 focus:outline-none" required>
      </div>

      <div>
        <label class="block text-sm font-medium mb-1">Email</label>
        <input name="email" type="email" value="<?php echo htmlspecialchars($_POST['email'] ?? ''); ?>" class="w-full border border-gray-300 px-3 py-2 rounded focus:ring-2 focus:ring-indigo-400 focus:outline-none" required>
      </div>

      <div>
        <label class="block text-sm font-medium mb-1">Subject</label>
        <input name="subject" value="<?php echo htmlspecialchars($_POST['subject'] ?? ''); ?>" class="w-full border border-gray-300 px-3 py-2 rounded focus:ring-2 focus:ring-indigo-400 focus:outline-none">
      </div>

      <div>
        <label class="block text-sm font-medium mb-1">Message</label>
        <textarea name="message" rows="5" class="w-full border border-gray-300 px-3 py-2 rounded focus:ring-2 focus:ring-indigo-400 focus:outline-none" required><?php echo htmlspecialchars($_POST['message'] ?? ''); ?></textarea>
      </div>

      <div>
        <button class="w-full bg-indigo-600 hover:bg-indigo-700 text-white py-2 rounded transition duration-300 font-semibold">Send Message</button>
      </div>
    </form>
  </div>
</section>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
